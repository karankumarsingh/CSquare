package com.karantestapplication.repository;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.karantestapplication.roomDatabase.UserDao;
import com.karantestapplication.roomDatabase.UserDatabase;
import com.karantestapplication.roomDatabase.UserTable;

import java.util.List;

public class UserRepository {

    private UserDao userDao;
    private LiveData<List<UserTable>> allData;
    private LiveData<UserTable> userTableLiveData;

    public UserRepository(Application application) {

        UserDatabase db = UserDatabase.getDatabase(application);
        userDao = db.userDoa();
        allData = userDao.getDetails();

    }

    public void deleteData() {
        userDao.deleteAllData();
    }

    public LiveData<List<UserTable>> getAllData() {
        return allData;
    }

    public LiveData<UserTable> getUserData(int id) {
        userDao.getDetails();
        userTableLiveData=userDao.getUserDetails(id);
        return userTableLiveData;
    }

    public void insertData(List<UserTable> data) {
        new UserInsertion(userDao).execute(data);
    }

    private static class UserInsertion extends AsyncTask<List<UserTable>, Void, Void> {

        private UserDao userDao1;

        private UserInsertion(UserDao loginDao) {

            this.userDao1 = loginDao;

        }

        @Override
        protected Void doInBackground(List<UserTable>... data) {
            userDao1.deleteAllData();
            userDao1.insertAllUsers(data[0]);
            return null;

        }

    }

}
