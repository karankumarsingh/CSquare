package com.karantestapplication.ui;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.karantestapplication.R;
import com.karantestapplication.adapter.UsersAdapter;
import com.karantestapplication.model.user.UserList;
import com.karantestapplication.repository.UserRepository;
import com.karantestapplication.roomDatabase.UserTable;
import com.karantestapplication.uiState.UIState;
import com.karantestapplication.viewModel.UserViewModel;

import java.util.ArrayList;
import java.util.List;

public class UserListFragment extends Fragment implements UsersAdapter.UserClickListener, UIState {

    ProgressDialog progressDialog;
    UserRepository userRepository;
    UserViewModel userViewModel;
    SwipeRefreshLayout swipeContainer;
    RecyclerView recyclerViewUserList;
    TextView textViewUserCount;
    UsersAdapter usersAdapter;
    List<UserList> userList;
    private int pageCount=1;
    private int totalPage=0;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        userList=new ArrayList<>();
        View view=inflater.inflate(R.layout.fragment_userlist, container, false);
        progressDialog=new ProgressDialog(getActivity());
        userRepository=new UserRepository(getActivity().getApplication());
        setUI(view);
        setObserver();
        return view;
    }

    private void setUI(View view) {
        swipeContainer = view.findViewById(R.id.swipeContainer);
        // Setup refresh listener which triggers new data loading
        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                setObserver();
            }
        });
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);
        ////////////RecyclerView /////////////////
        recyclerViewUserList=view.findViewById(R.id.recyclerViewUserList);
        recyclerViewUserList.setHasFixedSize(false);
        recyclerViewUserList.setLayoutManager(new LinearLayoutManager(getActivity()));
        usersAdapter=new UsersAdapter(getActivity(), userList, this);
        recyclerViewUserList.setAdapter(usersAdapter);
        textViewUserCount=view.findViewById(R.id.textViewUserCount);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private void setObserver() {
        //////////////ViewModel implementation//////////////////
        userViewModel= ViewModelProviders.of(this).get(UserViewModel.class);
        userViewModel.getUser(""+pageCount).observe(this, userResponse -> {
            if(userResponse!=null){
                swipeContainer.setRefreshing(false);
                totalPage=userResponse.getTotalPages();
                if(pageCount<=totalPage) {
                    userList.addAll(userResponse.getData());
                    usersAdapter = new UsersAdapter(getActivity(), userList, UserListFragment.this);
                    recyclerViewUserList.setAdapter(usersAdapter);
                    pageCount++;
                    textViewUserCount.setText(getResources().getString(R.string.user_count)+" "+userList.size());
                    insertData(userResponse.getData());
                }
            }
        });
    }

    @Override
    public void click(int pos) {
        Bundle bundle=new Bundle();
        bundle.putInt(getResources().getString(R.string.reqres_id), userList.get(pos).getId());
        UserDetailsFragment userDetailsFragment=new UserDetailsFragment();
        userDetailsFragment.setArguments(bundle);
        getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.container, userDetailsFragment, "").addToBackStack(null).commit();
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    public void insertData(List<UserList> userList){
        List<UserTable> userTableList=new ArrayList<>();
        UserTable userTable=new UserTable();
        for (int i = 0; i < userList.size(); i++) {
            userTable=new UserTable();
            userTable.setId(userList.get(i).getId());
            userTable.setAvatar(userList.get(i).getAvatar());
            userTable.setEmail(userList.get(i).getEmail());
            userTable.setFirstName(userList.get(i).getFirstName());
            userTable.setLastName(userList.get(i).getLastName());
            userTableList.add(userTable);
        }
        userRepository.insertData(userTableList);
    }

    @Override
    public void showLoader() {
        progressDialog.setMessage("Loading...");
        progressDialog.show();
    }

    @Override
    public void dismissLoader() {
        if(progressDialog!=null&&progressDialog.isShowing())
            progressDialog.dismiss();
    }
}
