package com.karantestapplication.viewModel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.karantestapplication.model.login.LoginData;
import com.karantestapplication.retrofit.ApiService;
import com.karantestapplication.retrofit.RetrofitClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class LoginViewModel extends ViewModel {
    private MutableLiveData<LoginData> loginMutableLiveData;

    public LiveData<LoginData> doLogin(String email, String password){
        if(loginMutableLiveData==null){
            loginMutableLiveData= new MutableLiveData<>();
            requestLogin(email, password);
        }
        return loginMutableLiveData;
    }

    private void requestLogin(String email, String pass) {
       Retrofit retrofitClient =new RetrofitClient().getInstance(ApiService.BASE_URL);
       ApiService apiService=retrofitClient.create(ApiService.class);
       apiService.doLogin(email, pass).enqueue(new Callback<LoginData>() {
           @Override
           public void onResponse(Call<LoginData> call, Response<LoginData> response) {
               loginMutableLiveData.setValue(response.body());
           }

           @Override
           public void onFailure(Call<LoginData> call, Throwable t) {
                loginMutableLiveData.setValue(null);
           }
       });
    }
}
