package com.karantestapplication.roomDatabase;


import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface UserDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAllUsers(List<UserTable> userTables);
    @Query("select * from UserDetail")
    LiveData<List<UserTable>> getDetails();

    @Query("select * from UserDetail where id=:id")
    LiveData<UserTable> getUserDetails(int id);

    @Query("delete from UserDetail")
    void deleteAllData();

}
