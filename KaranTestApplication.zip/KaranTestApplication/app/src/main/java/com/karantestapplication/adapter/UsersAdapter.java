package com.karantestapplication.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.karantestapplication.R;
import com.karantestapplication.model.user.UserList;

import java.util.List;

public class UsersAdapter extends RecyclerView.Adapter<UsersAdapter.UsersViewHolder> {
    private Context mCtx;
    private List<UserList> mUserList;
    private UserClickListener mUserClickListener;

    public UsersAdapter(Context mCtx, List<UserList> userList, UserClickListener userClickListener) {
        this.mCtx = mCtx;
        this.mUserList = userList;
        this.mUserClickListener=userClickListener;
    }

    @NonNull
    @Override
    public UsersAdapter.UsersViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mCtx).inflate(R.layout.row_user, parent, false);
        return new UsersViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UsersAdapter.UsersViewHolder holder, int position) {
        UserList user = mUserList.get(position);

        Glide.with(mCtx).load(user.getAvatar()).into(holder.imageView);

        holder.textView.setText(user.getFirstName()+" "+user.getLastName());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mUserClickListener !=null){
                    mUserClickListener.click(position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mUserList.size();
    }

    class UsersViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView;
        TextView textView;

        public UsersViewHolder(View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.imageViewAvatar);
            textView = itemView.findViewById(R.id.textViewUserName);
        }
    }

    public interface UserClickListener {
        void click(int pos);
    }
}
