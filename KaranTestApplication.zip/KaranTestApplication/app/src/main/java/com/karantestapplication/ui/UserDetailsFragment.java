package com.karantestapplication.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.karantestapplication.R;
import com.karantestapplication.repository.UserRepository;
import com.karantestapplication.roomDatabase.UserTable;

public class UserDetailsFragment extends Fragment {
    private TextView textViewUserId, textViewName, textViewEmailAddress;
    private ImageView imageViewAvatar;
    UserRepository userRepository;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_user_details, container, false);
        setUI(view);
        setRepository();
        return view;
    }

    private void setUI(View view){
        textViewUserId =view.findViewById(R.id.textViewUserId);
        textViewName =view.findViewById(R.id.textViewName);
        textViewEmailAddress =view.findViewById(R.id.textViewEmailAddress);
        imageViewAvatar=view.findViewById(R.id.imageViewAvatar);
    }

    private void setRepository() {
        userRepository=new UserRepository(this.getActivity().getApplication());
        userRepository.getUserData(getArguments().getInt(getResources().getString(R.string.reqres_id))).observe(this, userTables -> {
            if(userTables!=null){
                setData(userTables);
            }
        });
    }

    private void setData(UserTable userTable) {
        textViewUserId.setText(getResources().getString(R.string.reqres_id)+" "+userTable.getId());
        textViewName.setText(getResources().getString(R.string.name)+" "+userTable.getFirstName()+" "+userTable.getLastName());
        textViewEmailAddress.setText(getResources().getString(R.string.email)+" "+userTable.getEmail());
        Glide.with(getContext()).load(userTable.getAvatar()).into(imageViewAvatar);
    }


}
