package com.karantestapplication.uiState;

public interface UIState {
    void showLoader();
    void dismissLoader();

}
