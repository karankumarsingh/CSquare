package com.karantestapplication.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.snackbar.Snackbar;
import com.karantestapplication.R;
import com.karantestapplication.model.login.LoginData;
import com.karantestapplication.uiState.UIState;
import com.karantestapplication.viewModel.LoginViewModel;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener, UIState {

    ProgressDialog progressDialog;
    LoginViewModel loginViewModel;
    ConstraintLayout parentView;
    EditText editTextEmailAddress;
    EditText editTextPassword;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        progressDialog=new ProgressDialog(this);
        loginViewModel= ViewModelProviders.of(this).get(LoginViewModel.class);
        setUI();
    }

    private void setUI(){
        parentView=findViewById(R.id.parentView);
        editTextEmailAddress=findViewById(R.id.editTextEmailAddress);
        editTextPassword=findViewById(R.id.editTextPassword);
        btnLogin=findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void submit(){
        doValidate(editTextEmailAddress.getText().toString(), editTextPassword.getText().toString());
    }

    private void doValidate(String email, String password) {
        if(isValidCredentials(email, password)){
            showLoader();
            doLogin(email, password);
        }
    }

    private boolean isValidCredentials(String email, String password){
        if(email.isEmpty()){
            Snackbar.make(parentView, "Please enter email address", Snackbar.LENGTH_LONG).show();
            return false;
        }else if(password.isEmpty()){
            Snackbar.make(parentView, "Enter password", Snackbar.LENGTH_LONG).show();
            return false;
        }
        return true;
    }
    private void doLogin(String email, String pass) {
        loginViewModel.doLogin(email, pass).observe(this, new Observer<LoginData>(){
            @Override
            public void onChanged(LoginData loginData) {
                if(loginData!=null&&!loginData.getToken().isEmpty()) {
                    startActivity(new Intent(LoginActivity.this, MainActivity.class));
                }
                dismissLoader();
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnLogin:
                submit();
                break;
        }
    }

    @Override
    public void showLoader() {
        progressDialog.setMessage("Loading...Please wait...");
            progressDialog.show();
    }

    @Override
    public void dismissLoader() {
        if(progressDialog!=null&&progressDialog.isShowing())
            progressDialog.dismiss();
    }
}