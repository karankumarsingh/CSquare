package com.karantestapplication.ui;

import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.karantestapplication.R;


public class MainActivity extends AppCompatActivity implements FragmentManager.OnBackStackChangedListener {

    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setUpToolbar();
        callFragment();
    }
    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void setUpToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name));

    }


    private void callFragment(){
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.addOnBackStackChangedListener(MainActivity.this);
        fragmentManager.beginTransaction().replace(R.id.container, new UserListFragment(), "UserListFragment").addToBackStack(null).commit();
    }

    @Override
    public void onBackStackChanged() {
        try {
            Fragment fr = getSupportFragmentManager().findFragmentById(R.id.container);
            final String fm_name = fr.getClass().getSimpleName();
            if (fm_name.contentEquals("UserDetailsFragment")) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            } else if(fm_name.contentEquals("UserListFragment")){
                getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            } else {
                getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            }

        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}