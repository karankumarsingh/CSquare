package com.karantestapplication.viewModel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.karantestapplication.model.user.UserList;
import com.karantestapplication.model.user.UserResponse;
import com.karantestapplication.repository.UserRepository;
import com.karantestapplication.retrofit.ApiService;
import com.karantestapplication.retrofit.RetrofitClient;
import com.karantestapplication.roomDatabase.UserTable;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class UserViewModel extends ViewModel {
    MutableLiveData<UserResponse> userResponseMutableLiveData;

    public LiveData<UserResponse> getUser(String pageCount){
            userResponseMutableLiveData=new MutableLiveData<>();
            fetchUserData(pageCount);
        return userResponseMutableLiveData;
    }

    private void fetchUserData(String mPageCount) {
        Retrofit retrofit= RetrofitClient.getInstance(ApiService.BASE_URL);
        ApiService apiService=retrofit.create(ApiService.class);
        Call<UserResponse> userResponseCall=apiService.getUserList(mPageCount);
        userResponseCall.enqueue(new Callback<UserResponse>() {
            @Override
            public void onResponse(Call<UserResponse> call, Response<UserResponse> response) {
                if(response!=null&&response.isSuccessful()){
                    userResponseMutableLiveData.setValue(response.body());
                }
            }

            @Override
            public void onFailure(Call<UserResponse> call, Throwable t) {
                userResponseMutableLiveData.setValue(null);
            }
        });
    }
}
